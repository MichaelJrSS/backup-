<?php 

function generateTitulo($titulo) {
	echo '
	<div class="customTitle">
		<div class="customTitleDiv">
			<h2>'.$titulo.'</h2>
		</div>
	</div>
	';
}

?>