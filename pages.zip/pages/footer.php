	<footer>
	</footer>

	<script type="text/javascript" src="js/customJS.js"></script>

</body>
</html>