<?php 
	
	//include_once('connection.php');

	

			// send email
			mail("mateusdotto@gmail.com","My Test","Mensagem");
			
	
?>